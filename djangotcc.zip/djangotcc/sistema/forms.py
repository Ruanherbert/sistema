from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError

class AlunoForm(UserCreationForm):
    nome = forms.CharField(max_length=100)
    matricula = forms.CharField(max_length=20)
    curso = forms.CharField(max_length=20)
    email = forms.CharField(max_length=100)

    class Meta:
        model = User
        fields = ['username', 'nome', 'matricula', 'curso', 'email', 'password1', 'password2']

    def clean_email(self):
        e = self.cleaned_data['email']
        if User.objects.filter(email=e).exists():
            raise ValidationError('O E-mail: {} já está cadastrado.'.format(e))
        return e



class MonitorForm(UserCreationForm):
    nome = forms.CharField(max_length=100)
    matricula = forms.CharField(max_length=20)
    curso = forms.CharField(max_length=20)
    email = forms.CharField(max_length=100)
    disciplina = forms.CharField(max_length=50)

    class Meta:
        model = User
        fields = ['username', 'nome', 'matricula', 'curso', 'disciplina', 'email', 'password1', 'password2']

    def clean_email(self):
        e = self.cleaned_data['email']
        if User.objects.filter(email=e).exists():
            raise ValidationError('O E-mail: {} já está cadastrado.'.format(e))
        return e



class OrientadorForm(UserCreationForm):
    nome = forms.CharField(max_length=100)
    matricula = forms.CharField(max_length=20)
    curso = forms.CharField(max_length=20)
    email = forms.CharField(max_length=100)
    disciplina = forms.CharField(max_length=50)

    class Meta:
        model = User
        fields = ['username', 'nome', 'matricula', 'curso', 'disciplina', 'email', 'password1', 'password2']

    def clean_email(self):
        e = self.cleaned_data['email']
        if User.objects.filter(email=e).exists():
            raise ValidationError('O E-mail: {} já está cadastrado.'.format(e))
        return e


